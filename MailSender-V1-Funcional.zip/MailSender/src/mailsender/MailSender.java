/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mailsender;

import java.util.Scanner;


/**
 *
 * @author jcarrillo
 *
 *
 */
public class MailSender {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        InfoAuth infoData = new InfoAuth();
        GetHTML getHtml = new GetHTML();
        //Scanner en = new Scanner(System.in);
        //String datos[] = new String[8];
        
        infoData.setTtls_true_false("true");
        infoData.setServer("smtp.gmail.com");
        infoData.setPort("587");
        infoData.setPath("/home/jcarrillo/archivo.txt");
        infoData.setUrl("http://www.google.com");
        infoData.setUser("juan.carrillo@acklins.net");
        infoData.setPassword("juancarrillo");
        infoData.setFrom("juan.carrillo@acklins.net");
        infoData.setTo("juan.carrillo@acklins.net");
        infoData.setCc("juan.carrillo@acklins.net,diego.moreano@acklins.net");
        infoData.setBcc("juan.carrillo@acklins.net");
        infoData.setSubject("MENSAJE PRUEBA");
        //infoData.setBody("MENSAJE" + getHtml.getHTML(url));
        if(getHtml.getHTML(infoData.getUrl())==null)
            infoData.setBody("ESTE ES EL BODY DEL MENSAJE...");
        else
            infoData.setBody("MENSAJE \n\n" + getHtml.getHTML(infoData.getUrl()));
            
        //infoData.sender(infoData,ttls_true_false ,server, port, path);
        infoData.sender();
        

//        while (datos.toString()!= "") {
//         System.out.println("introduzca usuario:"); 
//         datos[0] = en.next();
//        }

       
                //USER
        /*
        System.out.println("introduzca usuario:");
        user = en.next();
        datos[0] = "juan.carrillo@acklins.net";
        //PASSWORD
        System.out.println("introduzca password:");
        //datos[1]=en.next();
        datos[1] = "juancarrillo";
        //FROM
        System.out.println("introduzca from:");
        //datos[2] = en.next();
        datos[2] = "juan.carrillo@acklins.net";
        //TO
        System.out.println("introduzca to:");
        //datos[3] = en.next();
        datos[3] = "juan.carrillo@acklins.net";
        //CC
        System.out.println("introduzca CC:");
        //datos[4] = en.next();
        datos[4] = "juan.carrillo@acklins.net";
        //BCC
        System.out.println("introduzca BCC:");
        //datos[5] = en.next();
        datos[5] = "juan.carrillo@acklins.net";
        //SUBJECT
        System.out.println("introduzca Subject:");
        //datos[6] = en.next();
        datos[6] = "Mensaje de prueba";
        //BODY
        System.out.println("introduzca Body - HTML:SI / Text:NO:");
        datos[7] = getHtml.getHTML(url);
        
       */
        
        

    }
}
