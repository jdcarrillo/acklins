/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mataproceso;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author jcarrillo
 */
public class MataProceso {

    /**
     * @param args the command line arguments
     */
    public static void main(String... args) throws java.io.IOException, InterruptedException, SQLException {

        TimerTask timerTask;
        timerTask = new TimerTask() {
            
            archivoLocal creaArchivo =  new archivoLocal();
            leeArchivo archivo = new leeArchivo();

            String nombreTienda = "SEGAFREDO";
            String statusTienda = "0";
            
            @Override
            public void run() {

                ComprobarConexion comconexion = new ComprobarConexion();
                boolean comprobar = comconexion.ComprobarConexion();
                //String estado;
                //COMPRUEBA CONEXION A LA BASE DE DATOS
                if (comprobar == true) {
                    /////////////
                    

                    
                    //////////////
                    creaArchivo.escribir(nombreTienda,statusTienda);

                    consultaNombreTienda consulta = new consultaNombreTienda();

                    //EXTRAE DATOS DE TIENDA
                    String extraeDatos = archivo.leer("c:\\archivo.txt");
                    //System.out.println("***Leyo: " + archivo.leer("/home/jcarrillo/archivo.txt")); //LINUX
                    //String extraeDatos=archivo.leer("c:archivo.txt");
                    String extraeNombre = extraeDatos.split(":")[0]; //EXTRAE NOMBRE TIENDA
                    String extraeStatus = extraeDatos.split(":")[1]; //EXTRAE STATUS DE TIENDA
                    System.out.println("Nombre: " + extraeNombre + " Status: " + extraeStatus);


                    //CONSULTA SI EXISTE LA TIENDA Y ACCEDE A LA VERIFICACION DE STATUS
                    if (consulta.encuentraTienda(nombreTienda)) {
                        System.out.println("***TIENDA ENCONTRADA***");

                        //estado=String.valueOf(archivo.leer("/home/jcarrillo/archivo.txt"));      //WINDOWS
                        //estado = String.valueOf(archivo.leer("c:archivo.txt"));

                        //SI EL STATUS DE LA TIENDA ENCONTRADA ES 0 BAJA LA APLICACION
                        if (extraeStatus.equals("0")) {
                            //if (extraeStatus.equals("0")) {
                            //System.out.println("leyo " + archivo.leer("/home/jcarrillo/archivo.txt"));
                            //Process p = new ProcessBuilder("calc").start();
                            //p.destroy();
                            try {
                                String[] cmd = {"TASKKILL", "/F", "/IM", "notepad.exe"}; //Comando de apagado en windows
                                Runtime.getRuntime().exec(cmd);
                            } catch (IOException ioe) {
                                System.out.println(ioe);

                            }
                        } else;
                    } else {
                        System.out.println("***TIENDA NO ENCONTRADA***");
                    }
                }//cierra comprobacion de conexion al Servidor de Base de Datos
                else {//////////REVISA ARCHIVO LOCAL SI NO EXISTA CONEXION////////////////////////

                    //EXTRAE DATOS DE TIENDA
                    String extraeDatos = archivo.leer("c:\\archivo.txt");
                    //System.out.println("***Leyo: " + archivo.leer("/home/jcarrillo/archivo.txt")); //LINUX
                    //String extraeDatos=archivo.leer("c:archivo.txt");
                    String extraeNombre = extraeDatos.split(":")[0]; //EXTRAE NOMBRE TIENDA
                    String extraeStatus = extraeDatos.split(":")[1]; //EXTRAE STATUS DE TIENDA
                    System.out.println("Nombre: " + extraeNombre + " Status: " + extraeStatus);


                    //CONSULTA SI EXISTE LA TIENDA Y ACCEDE A LA VERIFICACION DE STATUS
                    if (extraeNombre.equals(nombreTienda)) {
                        System.out.println("***TIENDA ENCONTRADA***");

                        //estado=String.valueOf(archivo.leer("/home/jcarrillo/archivo.txt"));      //WINDOWS
                        //estado = String.valueOf(archivo.leer("c:archivo.txt"));

                        //SI EL STATUS DE LA TIENDA ENCONTRADA ES 0 BAJA LA APLICACION
                        if (extraeStatus.equals("0")) {
                            //if (extraeStatus.equals("0")) {
                            //System.out.println("leyo " + archivo.leer("/home/jcarrillo/archivo.txt"));
                            //Process p = new ProcessBuilder("calc").start();
                            //p.destroy();
                            try {
                                String[] cmd = {"TASKKILL", "/F", "/IM", "notepad.exe"}; //Comando de apagado en windows
                                Runtime.getRuntime().exec(cmd);
                            } catch (IOException ioe) {
                                System.out.println(ioe);

                            }
                        } else;
                    } else {
                        System.out.println("***TIENDA NO ENCONTRADA***");
                    }

                }//FIN DE REVISION DE ARCHIVO SIN CONEXION
            }
        };


        Timer timer = new Timer();
        timer.scheduleAtFixedRate(timerTask, 0, 1000);


    }

}
