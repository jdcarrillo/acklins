/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mataproceso;
import java.io.*;
/**
 *
 * @author jcarrillo
 */
public class archivoLocal {

    //no olviden importar esta librería al inicio de su programa
    //esto es solo un método, no una clase, el método deberá ser incluido en una clase java para su uso
    public void escribir(String nombreTienda,String statusTienda) {
        File f;
        f = new File("/home/jcarrillo/creo.txt");

        //Escritura
        try {
            FileWriter w = new FileWriter(f);
            BufferedWriter bw = new BufferedWriter(w);
            PrintWriter wr = new PrintWriter(bw);
            wr.write(nombreTienda+":"+statusTienda);//escribimos en el archivo
            //wr.append(" - y aqui continua"); //concatenamos en el archivo sin borrar lo existente
            //ahora cerramos los flujos de canales de datos, al cerrarlos el archivo quedará guardado con información escrita
            //de no hacerlo no se escribirá nada en el archivo
            wr.close();
            bw.close();
        } catch (IOException e) {
        };
    }
}
