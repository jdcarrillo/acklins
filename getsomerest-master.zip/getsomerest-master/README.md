getsomerest
===========

Example source code for the article "RESTful Java Web Services with NetBeans, Jersey and Tomcat"

Build
=====

1. Configure NetBeans and Tomcat according to my blog article.
2. Start NetBeans.
3. Select File > Open Project in NetBeans.
4. Open the getsomerest project.
4. Right click on the project then select Run.
