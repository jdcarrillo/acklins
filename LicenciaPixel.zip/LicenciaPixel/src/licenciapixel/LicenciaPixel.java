/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package licenciapixel;

/**
 *
 * @author jcarrillo
 */
public class LicenciaPixel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frmLicenciasPixel frmLicencias = new frmLicenciasPixel();
        frmLicencias.show();
    }
}
